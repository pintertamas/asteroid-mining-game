public enum GameState {
    IN_PROGRESS,
    WON,
    LOST,
}
