public class BillOfPortal extends BillOfMaterials {

    public BillOfPortal() {
        super();
        this.bill.put(Iron.class, 2);
        this.bill.put(Ice.class, 1);
        this.bill.put(Uranium.class, 1);
    }
}

