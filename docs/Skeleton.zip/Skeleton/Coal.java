public class Coal extends Material {
    @Override
    protected boolean isCompatibleWith(Material m) {
        return false;
    }
}
